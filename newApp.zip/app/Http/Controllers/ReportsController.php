<?php

namespace App\Http\Controllers;

use App\Models\Items;
use App\Models\ReceivingsItems;
use App\Models\Reports;
use App\Models\SalesItem;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportsController extends Controller
{
    public function index()
    {
        return view('reports.index');
    }

    public function graphical_summary($id)
    {
        return view('reports.graphical_summary_categories');
    }
    public function graphical_summary_sales($url, $startDate, $endDate, $saleType, $locationId)
    {
        $data = [
            'startDate' => $startDate,
            'endDate' => $endDate,
            'saleType' => $saleType,
            'location' => $locationId
        ];
        return view('receiving.graphical', compact('data'));
    }
    public function summaryList($id)
    {
        return view('reports.graphical_summary_categories');
    }
    public function detailed(Request $request, $id)
    {
        if ($request->isMethod('post')) {
            $start_date = Carbon::parse($request->startdate)
                ->toDateTimeString();
            $end_date = Carbon::parse($request->enddate)
                ->toDateTimeString();
            if ($request->segment(1) ==  'reports' && $request->segment(2) ==  'detailed_taxes') {
                $sales_items = SalesItem::with('item', 'sales')->whereBetween('created_at', [$start_date, $end_date])->get();
            } elseif ($request->segment(1) ==  'reports' && $request->segment(2) ==  'detailed_receivings') {
                $sales_items = ReceivingsItems::with('item')->whereBetween('created_at', [$start_date, $end_date])->get();
            }
            return view('reports.details_final_report', compact('sales_items', 'start_date', 'end_date'));
        }
        return view('reports.details');
    }
    public function specific($id)
    {
        return view('reports.graphical_summary_categories');
    }
    public function inventory($id)
    {
        $items = Items::where('quantity', '<', 10)->get();

        return view('reports.low_inventory', compact('items'));
        // return view('reports.download_low', compact('items'));
    }
    public function export()
    {
        return view('reports.testingreport');
    }
}
