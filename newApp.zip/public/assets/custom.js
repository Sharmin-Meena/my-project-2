$(document).ready(function (){
    $('#employeetable').dataTable( {
        "searching": true
    } );
    $('#managetable').dataTable( {
        "searching": true
    } );
    $('#itemkitstable').dataTable( {
        "searching": true
    } );
    $('#table').dataTable( {
        "searching": true,
        'pagination':false
    } );


});
