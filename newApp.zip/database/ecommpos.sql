-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2021 at 05:57 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommpos`
--

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

CREATE TABLE `attributes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`id`, `name`, `created_at`, `updated_at`) VALUES
(2, 'Color', '2021-09-15 01:51:11', '2021-09-15 01:51:11'),
(3, 'Size', '2021-09-15 03:02:27', '2021-09-15 03:02:27'),
(4, 'Ram', '2021-09-15 03:05:45', '2021-09-15 03:05:45');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_values`
--

CREATE TABLE `attribute_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attribute_values`
--

INSERT INTO `attribute_values` (`id`, `value`, `attribute_id`, `created_at`, `updated_at`) VALUES
(7, 'Green', 2, '2021-09-15 01:51:11', '2021-09-15 01:51:11'),
(8, 'White', 2, '2021-09-15 01:51:12', '2021-09-15 01:51:12'),
(9, 'Black', 2, '2021-09-15 01:51:12', '2021-09-15 01:51:12'),
(10, 'Red', 2, '2021-09-15 01:51:12', '2021-09-15 01:51:12'),
(11, 'S', 3, '2021-09-15 03:02:27', '2021-09-15 03:02:27'),
(12, 'L', 3, '2021-09-15 03:02:27', '2021-09-15 03:02:27'),
(13, 'M', 3, '2021-09-15 03:02:27', '2021-09-15 03:02:27'),
(14, 'XL', 3, '2021-09-15 03:02:27', '2021-09-15 03:02:27'),
(15, 'XXL', 3, '2021-09-15 03:02:27', '2021-09-15 03:02:27'),
(16, '4GB', 4, '2021-09-15 03:05:45', '2021-09-15 03:05:45'),
(17, '8GB', 4, '2021-09-15 03:05:45', '2021-09-15 03:05:45'),
(18, '16GB', 4, '2021-09-15 03:05:45', '2021-09-15 03:05:45'),
(19, '64GB', 4, '2021-09-15 03:05:45', '2021-09-15 03:05:45');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `item_id` bigint(20) UNSIGNED DEFAULT NULL,
  `tempusertoken` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `item_id`, `tempusertoken`, `quantity`, `created_at`, `updated_at`) VALUES
(7, 3, 3, 'rPxYWw0k1DIr6jwg', 1.00, '2021-09-12 06:43:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(14, 0, 'Electronics', NULL, '2021-09-14 09:10:42', '2021-09-14 09:10:42'),
(15, 14, 'Smart Phone', NULL, '2021-09-14 09:10:56', '2021-09-14 09:10:56'),
(16, 15, 'Nokia', NULL, '2021-09-14 09:11:26', '2021-09-14 09:11:26');

-- --------------------------------------------------------

--
-- Table structure for table `categories_items`
--

CREATE TABLE `categories_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `item_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories_items`
--

INSERT INTO `categories_items` (`id`, `category_id`, `item_id`, `created_at`, `updated_at`) VALUES
(3, 14, 4, NULL, NULL),
(4, 15, 4, NULL, NULL),
(5, 16, 4, NULL, NULL),
(6, 14, 5, NULL, NULL),
(7, 16, 5, NULL, NULL),
(8, 15, 6, NULL, NULL),
(9, 16, 6, NULL, NULL),
(10, 14, 7, NULL, NULL),
(11, 15, 7, NULL, NULL),
(12, 16, 7, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `coupon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` int(11) NOT NULL,
  `coupon_validity` date DEFAULT NULL,
  `price_limit` double(8,2) DEFAULT NULL,
  `used` int(11) NOT NULL DEFAULT 0 COMMENT 'How Many time used this coupon',
  `max_used` int(11) DEFAULT NULL COMMENT 'How Many time you want  used this coupon',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `coupon`, `value`, `coupon_validity`, `price_limit`, `used`, `max_used`, `created_at`, `updated_at`) VALUES
(1, 'mf10', 10, '2021-09-30', NULL, 2, 50, '2021-09-09 09:52:19', '2021-09-12 14:48:30'),
(2, 'mf50', 50, '2021-09-30', 40000.00, 0, 40, '2021-09-09 09:52:19', NULL),
(4, 'mf15', 15, '2021-09-24', 15.00, 0, 50, '2021-09-12 14:29:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `first_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` set('m','f','o') COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address1` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `discount` int(11) NOT NULL,
  `taxable` tinyint(4) NOT NULL DEFAULT 0,
  `comments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `user_id`, `first_name`, `last_name`, `gender`, `email`, `phone`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `company`, `account`, `total`, `discount`, `taxable`, `comments`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Alderedo 22', 'Mannfa 22', 'm', 'mannaf@gmail.com', '01744508287', 'Bhety bangal para', 'nai', 'Naogaon', 'Rajshahi', '5890', 'Bangladesh', 'AtoZ3', '3534534', '22.50', 12, 1, 'asfd', '2021-08-28 08:20:15', '2021-09-12 04:50:50'),
(4, 3, 'a22', 'Andrea', 'm', 'mannaf@gmail.com', '04564657', 'Beltola', 'nai', 'Naogaon', 'Rajshahi', '587445', 'Bangladesh', 'nai', 'nai', '0.00', 0, 1, 'nai', '2021-09-12 05:04:35', '2021-09-12 05:05:37'),
(5, 6, 'Alderedo', 'Mannfa', 'm', 'robot@gmail.com', '01744508287', 'Bhety bangal para', 'nai', 'Naogaon', 'Rajshahi', '5890', 'Bangladesh', 'nai', 'nai', '0.00', 0, 1, 'nai', '2021-09-12 22:57:17', '2021-09-12 22:57:17'),
(6, 5, 'Alderedo', 'Mannfa', 'm', 'admin2@gmail.com', '01744508287', 'Bhety bangal para', 'nai', 'Naogaon', 'Rajshahi', '5890', 'Bangladesh', 'nai', 'nai', '0.00', 0, 1, 'nai', '2021-09-14 09:24:50', '2021-09-14 09:24:50');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `loginname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` set('m','f','o') COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employeeid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `loginname`, `user_id`, `password`, `role`, `first_name`, `last_name`, `gender`, `phone`, `email`, `image`, `employeeid`, `created_at`, `updated_at`) VALUES
(1, 'mannaf456', NULL, '123456', '6', 'Abdul', 'mannaf', 'm', '0275418785', 'abdemannafbd@gmail.com', 'mannaf456.jpg', '10', '2021-08-29 07:31:08', '2021-09-01 07:43:09'),
(2, 'mannafdev', NULL, '123456', '6', 'AbdulDevid', 'Mannaf', 'f', '01745879856', 'devid@gmail.com', 'mannafdev.jpg', '12', '2021-09-01 06:47:43', '2021-09-01 07:45:18'),
(3, 'robot55', NULL, '$2y$10$lDytiHP0spDBEFUiwH9rPOfrLWbIs5vhrib1jdyT7r6BJqvYI1N4C', '6', 'Robort', 'DEV', 'm', '0178546456', 'robot55@gmail.com', 'Robort.jpg', '12', '2021-09-02 06:47:42', '2021-09-02 06:47:42'),
(4, 'Employee2', 10, '$2y$10$LpKPgyOJSZ5/tKJLPiX6c.D09NYmRKn.SqGZS5Nt4ewa5ujX3rIJC', '6', 'Employee2', 'New', 'm', '0174458796', 'employee2@gmail.com', 'Employee2.jpg', '12', '2021-09-17 05:38:14', '2021-09-17 05:38:14');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `giftcards`
--

CREATE TABLE `giftcards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `card_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_date` date NOT NULL,
  `value` int(11) NOT NULL,
  `card_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `giftcards`
--

INSERT INTO `giftcards` (`id`, `customer_id`, `card_number`, `expire_date`, `value`, `card_image`, `created_at`, `updated_at`) VALUES
(6, 1, '1010101010', '2021-09-14', 700, NULL, '2021-09-04 22:56:21', '2021-09-04 22:56:21'),
(7, 1, '1010101011', '2021-09-30', 500, NULL, '2021-09-04 23:25:56', '2021-09-04 23:25:56');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `item_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `item_id`, `name`, `note`, `created_at`, `updated_at`) VALUES
(4, 4, '0e285a5c26245dd0a0d8513dfb821dce.jpg', 'uploads/product/0e285a5c26245dd0a0d8513dfb821dce.jpg', '2021-09-14 10:42:01', '2021-09-14 10:42:01'),
(5, 4, 'e090eb002f6d0651bf22aa4a5dff0b68.jpg', 'uploads/product/e090eb002f6d0651bf22aa4a5dff0b68.jpg', '2021-09-14 10:42:01', '2021-09-14 10:42:01'),
(6, 4, '37bfbe1a6668ea57c59efbf0b3f701f3.png', 'uploads/product/37bfbe1a6668ea57c59efbf0b3f701f3.png', '2021-09-14 10:42:01', '2021-09-14 10:42:01'),
(7, 5, '29d049b1124d59d0322964d7ecf393dd.png', 'uploads/product/29d049b1124d59d0322964d7ecf393dd.png', '2021-09-15 01:30:35', '2021-09-15 01:30:35'),
(8, 6, '902f8127b1ee5829eb9139ea76464eaf.png', 'uploads/product/902f8127b1ee5829eb9139ea76464eaf.png', '2021-09-15 01:32:01', '2021-09-15 01:32:01'),
(9, 7, '5f07187ea227ec49273ed73ddde46d7e.png', 'uploads/product/5f07187ea227ec49273ed73ddde46d7e.png', '2021-09-15 14:54:40', '2021-09-15 14:54:40');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` bigint(20) UNSIGNED DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cost_price` decimal(8,2) NOT NULL,
  `unit_price` decimal(8,2) NOT NULL,
  `reorder_level` int(11) NOT NULL,
  `quantity` double NOT NULL,
  `unit` set('gm','kg','lb','piece','dozon','l','ml','inch','foot') COLLATE utf8mb4_unicode_ci NOT NULL,
  `baseimage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alt_description` tinyint(4) NOT NULL DEFAULT 0,
  `has_serial` tinyint(4) NOT NULL DEFAULT 0,
  `serialno` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax1` tinyint(4) DEFAULT NULL,
  `tax2` tinyint(4) DEFAULT NULL,
  `attributes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`attributes`)),
  `loc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'item location in store',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `supplier_id`, `sku`, `description`, `cost_price`, `unit_price`, `reorder_level`, `quantity`, `unit`, `baseimage`, `alt_description`, `has_serial`, `serialno`, `tax1`, `tax2`, `attributes`, `loc`, `created_at`, `updated_at`) VALUES
(4, 'Nokia G20', 1, 'el-5050', '164.9 x 76 x 9.2 mm (6.49 x 2.99 x 0.36 in)\r\nWeight	197 g (6.95 oz)\r\nSIM	Single SIM (Nano-SIM) or Dual SIM (Nano-SIM, dual stand-by)\r\n 	Splash protection', '2400.00', '2500.00', 10, 50, 'piece', 'uploads/product/1631637900.png', 1, 1, '202020', 0, NULL, '{\"Color\":[\"Red\",\"Green\"],\"Size\":[\"Small\",\"Medium\",\"Large\"]}', 'rack-4', '2021-09-14 10:42:01', '2021-09-17 05:04:30'),
(7, 'Mannfa', 1, 'DEV-892', 'nai', '1200.00', '1300.00', 10, 150, 'kg', 'uploads/product/1631739280.jpg', 1, 1, 'safd', 0, NULL, '{\"Color\":[\"Green\",\"Black\"],\"Size\":[\"S\",\"XL\"],\"Ram\":[\"4GB\"]}', 'Dhaka', '2021-09-15 14:54:40', '2021-09-17 05:06:12');

-- --------------------------------------------------------

--
-- Table structure for table `item_kits`
--

CREATE TABLE `item_kits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `baseimage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `item_kits`
--

INSERT INTO `item_kits` (`id`, `name`, `description`, `baseimage`, `created_at`, `updated_at`) VALUES
(4, 'Def', 'DD', 'Def.jpg', '2021-09-16 01:37:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `item_kit_products`
--

CREATE TABLE `item_kit_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `item_kits_id` bigint(20) UNSIGNED DEFAULT NULL,
  `item_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `item_kit_products`
--

INSERT INTO `item_kit_products` (`id`, `item_kits_id`, `item_id`, `quantity`, `created_at`, `updated_at`) VALUES
(7, 4, 7, '5.00', '2021-09-16 01:37:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_09_01_182948_create_customers_table', 1),
(5, '2019_09_02_184906_create_suppliers_table', 1),
(6, '2019_09_03_041344_create_categories_table', 1),
(7, '2019_09_04_184055_create_items_table', 1),
(8, '2019_09_05_184457_create_item_kits_table', 1),
(9, '2019_09_06_045603_create_item_kit_products_table', 1),
(10, '2019_09_07_185922_create_employees_table', 1),
(11, '2019_09_08_185622_create_sales_table', 1),
(12, '2019_09_09_053519_create_sales_items_table', 1),
(13, '2019_09_30_190649_create_storeconfigs_table', 2),
(14, '2021_08_25_064541_create_categories_items_table', 3),
(15, '2021_08_25_064810_create_images_table', 3),
(16, '2019_09_10_034945_create_receivings_table', 4),
(17, '2019_09_11_035053_create_receivings_items_table', 4),
(18, '2019_09_11_044927_create_wishlists_table', 4),
(19, '2019_09_12_044949_create_carts_table', 4),
(20, '2021_09_02_174413_create_git_cards_table', 5),
(24, '2021_09_02_180441_create_giftcards_table', 6),
(27, '2021_09_04_170043_create_wishlists_table', 8),
(28, '2021_09_09_094251_create_coupons_table', 9),
(29, '2021_09_09_094646_create_who_useds_table', 9),
(30, '2021_09_12_070934_add_order_status_user_id_in_sales', 10),
(31, '2021_09_12_072445_create_shipping_details_table', 11),
(32, '2021_09_12_093311_add_user_id_to_customer', 12),
(34, '2021_09_12_124732_add_full_name_to_ship', 13),
(35, '2021_09_04_165908_create_attributes_table', 14),
(36, '2021_09_04_170043_create_attribute_values_table', 14),
(37, '2021_09_17_112302_add_user_id_to_employee', 15);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `receivings`
--

CREATE TABLE `receivings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_id` bigint(20) UNSIGNED DEFAULT NULL,
  `employee_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` double NOT NULL,
  `discount` double NOT NULL,
  `coupon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finaltotal` double NOT NULL,
  `payment_type` set('cash','bkash','nagad','ucash','rocket') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` set('incomplete','due','complete','partial') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `receivings_items`
--

CREATE TABLE `receivings_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `receivings_id` bigint(20) UNSIGNED DEFAULT NULL,
  `items_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` double NOT NULL,
  `unit_price` double NOT NULL,
  `cost_price` double NOT NULL,
  `discount_percent` double NOT NULL DEFAULT 0,
  `attributes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attributes`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `employee_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` double(8,2) NOT NULL,
  `discount` double(8,2) NOT NULL,
  `coupon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finaltotal` double(8,2) NOT NULL,
  `payment_type` set('cash','bkash','nagad','ucash','rocket') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` set('incomplete','due','complete','partial') COLLATE utf8mb4_unicode_ci NOT NULL,
  `sale_type` set('store','web') COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `order_status` set('pending','processing','shipped') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `invoice_id`, `customer_id`, `employee_id`, `comments`, `total`, `discount`, `coupon`, `finaltotal`, `payment_type`, `payment_status`, `sale_type`, `user_id`, `created_at`, `updated_at`, `order_status`) VALUES
(77, '45-645464110', 4, 1, 'afdssda', 6500.00, 0.00, 'nocoupon', 6500.00, 'cash', 'complete', 'store', NULL, '2021-09-17 05:00:42', NULL, 'pending'),
(78, '45-645464111', 4, 1, 'afdsfafds', 58500.00, 50.00, 'nocoupon', 58450.00, 'cash', 'complete', 'store', NULL, '2021-09-17 05:01:11', NULL, 'pending'),
(79, '45-645464112', 5, 1, 'asdfdsfad', 5200.00, 0.00, 'nocoupon', 5200.00, 'cash', 'complete', 'store', NULL, '2021-09-17 05:06:11', NULL, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `sales_items`
--

CREATE TABLE `sales_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sales_id` bigint(20) UNSIGNED DEFAULT NULL,
  `items_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` double NOT NULL,
  `unit_price` double NOT NULL,
  `cost_price` double NOT NULL,
  `discount_percent` double NOT NULL DEFAULT 0,
  `attributes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attributes`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales_items`
--

INSERT INTO `sales_items` (`id`, `sales_id`, `items_id`, `quantity`, `unit_price`, `cost_price`, `discount_percent`, `attributes`, `created_at`, `updated_at`) VALUES
(51, 77, 7, 5, 1300, 1200, 0, '{\"Color\":[\"Green\",\"Black\"],\"Size\":[\"S\",\"XL\"],\"Ram\":[\"4GB\"]}', '2021-09-17 05:00:42', NULL),
(52, 78, 7, 45, 1300, 1200, 0, '{\"Color\":[\"Green\",\"Black\"],\"Size\":[\"S\",\"XL\"],\"Ram\":[\"4GB\"]}', '2021-09-17 05:01:12', NULL),
(53, 79, 7, 4, 1300, 1200, 0, '{\"Color\":[\"Green\",\"Black\"],\"Size\":[\"S\",\"XL\"],\"Ram\":[\"4GB\"]}', '2021-09-17 05:06:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shipping_details`
--

CREATE TABLE `shipping_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sales_id` bigint(20) UNSIGNED DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `storeconfigs`
--

CREATE TABLE `storeconfigs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `storeconfigs`
--

INSERT INTO `storeconfigs` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'address', '123 Nowhere street', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(2, 'barcode_content', 'id', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(3, 'barcode_first_row', 'name', '2021-08-25 06:39:44', '2021-09-16 01:35:42'),
(4, 'barcode_font', 'Arial.ttf', '2021-08-25 06:39:44', '2021-09-16 01:35:42'),
(5, 'barcode_font_size', '10', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(6, 'barcode_generate_if_empty', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(7, 'barcode_height', '50', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(8, 'barcode_num_in_row', '2', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(9, 'barcode_page_cellspacing', '20', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(10, 'barcode_page_width', '100', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(11, 'barcode_quality', '100', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(12, 'barcode_second_row', 'category', '2021-08-25 06:39:44', '2021-09-16 01:35:42'),
(13, 'barcode_third_row', 'cost_price', '2021-08-25 06:39:44', '2021-09-16 01:35:43'),
(14, 'barcode_type', 'Code128', '2021-08-25 06:39:44', '2021-09-16 01:27:37'),
(15, 'barcode_width', '250', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(16, 'company', 'HUNULULU', '2021-08-25 06:39:44', '2021-09-16 00:55:29'),
(17, 'company_logo', NULL, '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(18, 'country_codes', 'us', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(19, 'currency_decimals', '2', '2021-08-25 06:39:44', '2021-09-16 01:20:48'),
(20, 'currency_symbol', '$', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(21, 'dateformat', 'Y/m/d', '2021-08-25 06:39:44', '2021-09-16 01:20:49'),
(22, 'default_sales_discount', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(23, 'default_tax_rate', '8', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(24, 'email', 'andrea@gmail.com', '2021-08-25 06:39:44', '2021-09-16 00:33:32'),
(25, 'fax', '65456', '2021-08-25 06:39:44', '2021-09-16 00:34:11'),
(26, 'invoice_default_comments', 'This is a default comment', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(27, 'invoice_email_message', 'Dear $CU, In attachment the receipt for sale $INV', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(28, 'invoice_enable', '1', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(29, 'language', 'es:spanish', '2021-08-25 06:39:44', '2021-09-16 01:20:48'),
(30, 'language_code', 'en', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(31, 'lines_per_page', '25', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(32, 'mailpath', '/usr/sbin/sendmail', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(33, 'msg_msg', '', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(34, 'msg_pwd', '', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(35, 'msg_src', '', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(36, 'msg_uid', '', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(37, 'notify_horizontal_position', 'center', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(38, 'notify_vertical_position', 'bottom', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(39, 'number_locale', 'en_US', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(40, 'payment_options_order', 'debitcreditcash', '2021-08-25 06:39:44', '2021-09-16 01:20:48'),
(41, 'phone', '04564657', '2021-08-25 06:39:44', '2021-09-16 00:33:32'),
(42, 'print_bottom_margin', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(43, 'print_footer', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(44, 'print_header', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(45, 'print_left_margin', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(46, 'print_right_margin', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(47, 'print_silently', '1', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(48, 'print_top_margin', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(49, 'protocol', 'mail', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(50, 'quantity_decimals', '2', '2021-08-25 06:39:44', '2021-09-16 01:20:48'),
(51, 'receipt_show_description', '1', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(52, 'receipt_show_serialnumber', '1', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(53, 'receipt_show_taxes', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(54, 'receipt_show_total_discount', '1', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(55, 'receipt_template', 'receipt_default', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(56, 'recv_invoice_format', '$CO', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(57, 'return_policy', 'Test', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(58, 'sales_invoice_format', '$CO', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(59, 'smtp_crypto', 'ssl', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(60, 'smtp_port', '465', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(61, 'smtp_timeout', '5', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(62, 'statistics', '1', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(63, 'tax_decimals', '2', '2021-08-25 06:39:44', '2021-09-16 01:20:48'),
(64, 'tax_included', '0', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(65, 'theme', 'center', '2021-08-25 06:39:44', '2021-09-16 00:53:41'),
(66, 'thousands_separator', '1', '2021-08-25 06:39:44', '2021-08-25 06:39:44'),
(67, 'timeformat', 'h:i:s a', '2021-08-25 06:39:44', '2021-09-16 01:20:49'),
(68, 'timezone', 'America/Kentucky/Monticello', '2021-08-25 06:39:44', '2021-09-16 01:20:49'),
(69, 'website', 'http://ecommpos.com', '2021-08-25 06:39:44', '2021-08-27 22:20:59'),
(76, 'established', '1953', '2021-08-27 22:21:32', '2021-08-27 22:21:32'),
(77, 'companyadd', 'DEV', '2021-09-14 13:17:20', '2021-09-16 00:33:45'),
(78, 'web', 'https://www.google.com/', '2021-09-16 00:15:48', '2021-09-16 00:33:26'),
(79, 'companylogo', '1631887539.png', '2021-09-16 00:20:28', '2021-09-17 08:05:39'),
(80, 'policy', 'fdsa', '2021-09-16 00:33:26', '2021-09-16 00:34:11'),
(81, 'tax1', '50', '2021-09-16 00:44:51', '2021-09-16 00:50:37'),
(82, 'cprice', '10', '2021-09-16 00:44:51', '2021-09-16 00:53:41'),
(83, 'area1', 'top', '2021-09-16 00:44:51', '2021-09-16 00:44:51'),
(84, 'area2', 'left', '2021-09-16 00:44:51', '2021-09-16 00:44:51'),
(85, 'c1', '55', '2021-09-16 00:44:51', '2021-09-16 00:53:41'),
(86, 'c12', NULL, '2021-09-16 00:44:51', '2021-09-16 00:44:51'),
(87, 'include_tax', '1', '2021-09-16 00:50:37', '2021-09-16 00:50:37'),
(88, 'line_per_page', '30', '2021-09-16 00:50:37', '2021-09-16 00:53:41'),
(89, 'calc_avg_price', '1', '2021-09-16 00:53:41', '2021-09-16 00:53:41'),
(90, 'send_statistc', '1', '2021-09-16 00:53:41', '2021-09-16 00:53:41'),
(91, 'c2', '55', '2021-09-16 00:53:41', '2021-09-16 00:53:41'),
(92, 'symble', '$', '2021-09-16 01:08:02', '2021-09-16 01:20:48'),
(93, 'ccode', 'us', '2021-09-16 01:08:02', '2021-09-16 01:08:02'),
(94, 'qty', '102', '2021-09-16 01:23:26', '2021-09-16 01:23:26'),
(95, 'width', '251', '2021-09-16 01:23:26', '2021-09-16 01:27:25'),
(96, 'weight', '49', '2021-09-16 01:23:26', '2021-09-16 01:35:42'),
(97, 'font', '10', '2021-09-16 01:23:26', '2021-09-16 01:23:26'),
(98, 'numrow', '2', '2021-09-16 01:23:26', '2021-09-16 01:23:26'),
(99, 'dpw', '101', '2021-09-16 01:23:26', '2021-09-16 01:35:43'),
(100, 'dpc', '204', '2021-09-16 01:23:26', '2021-09-16 01:35:43');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agency_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` set('m','f','o') COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address1` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address2` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comments` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `company_name`, `agency_name`, `account_number`, `first_name`, `last_name`, `gender`, `phone`, `email`, `address1`, `address2`, `city`, `state`, `zip`, `country`, `comments`, `created_at`, `updated_at`) VALUES
(1, 'AtoZ3', 'atoz.com', '46574564', 'Alderedo4', 'Mannfa4', 'm', '01744508287', 'mannaf444@gmail.com', 'Bhety bangal para', 'Abadpukur hat', 'Rajshahi', 'Rajshahi', '5890', 'Bangladesh', 'asfda', NULL, '2021-08-28 07:51:44'),
(2, 'Anaconda', 'acb.com', '7777777785', 'dev', 'debu', 'f', '01744508287', 'mannaf444@gmail.com', 'Bhety bangal para', 'Abadpukur hat', 'Naogaon', 'Rajshahi', '5890', 'Bangladesh', '2nd', NULL, '2021-08-28 09:53:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` set('1','2','3','4','5') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '2',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@gmail.com', NULL, '$2y$10$oE/tLVnnwe8CgSVMg5hBTO6pHTocciMUu8ANFM4s25d9tIYTujKeC', '1', NULL, '2021-08-25 00:23:54', '2021-08-25 00:23:54'),
(2, 'test', 'test@gmail.com', NULL, '$2y$10$ccIaiFmVV.um.uLIaz5t6.4lKaEYPhLbH.05I0JT4ax9rRIwGzmWC', '2', NULL, '2021-08-27 23:09:51', '2021-08-27 23:09:51'),
(3, 'mannaf', 'mannaf@gmail.com', NULL, '$2y$10$VE0s1MLPo790t/IkphaiAui/41.EcXm6yE3dO7WsYa7ikS/1NoKoe', '2', NULL, '2021-08-28 02:36:06', '2021-09-12 22:20:28'),
(4, 'Dev', 'mannaf444@gmail.com', NULL, '$2y$10$Zaztcmh6m2dR9NPDQ3NOP./3kovkVm1uGOsR11/gzIAyDGc5jEqVu', '2', NULL, '2021-09-07 10:25:17', '2021-09-12 22:14:38'),
(5, 'Alderedo Mannfa', 'admin2@gmail.com', NULL, '$2y$10$9gAiNuEZ8.sD7oIvQRu.YuDD6fEACt/n3AUYtvnfO9Hkffuz6kK0O', '1', NULL, NULL, NULL),
(6, 'Robot', 'robot@gmail.com', NULL, '$2y$10$uzHDH3.GL3MsGRFmYXZph.0WOdaN5t/S9N2O9b/IOQ30GzHC52b7S', '2', NULL, '2021-09-12 22:53:33', '2021-09-12 22:53:33'),
(7, 'supplier', 'supplier@gmail.com', NULL, '$2y$10$BckI.DM78ielaBM.XfHSx.5.ixQuu6YPetVD0HxLSLlnOoJ.eZPbe', '3', NULL, '2021-09-14 15:03:02', '2021-09-14 15:03:02'),
(8, 'employee', 'employee@gmail.com', NULL, '$2y$10$kmJHJXZ8wUfqlx327w0s2.9i4XHiSM4Cn9uxdKdfZNRIKxGoEoMG.', '5', NULL, '2021-09-14 15:05:19', '2021-09-14 15:05:19'),
(10, 'Employee2', 'employee2@gmail.com', NULL, '$2y$10$LpKPgyOJSZ5/tKJLPiX6c.D09NYmRKn.SqGZS5Nt4ewa5ujX3rIJC', '5', NULL, '2021-09-17 05:38:14', '2021-09-17 05:38:14'),
(11, 'manager', 'manager@gmail.com', NULL, '$2y$10$/Y9.JxFQGOHZlhym0mwImubhH9n3.nq5KvPHuf.9ir25DmYVd877C', '4', NULL, '2021-09-17 07:20:45', '2021-09-17 07:21:46');

-- --------------------------------------------------------

--
-- Table structure for table `who_useds`
--

CREATE TABLE `who_useds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `coupon_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `item_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attributes`
--
ALTER TABLE `attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attribute_values`
--
ALTER TABLE `attribute_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_values_attribute_id_foreign` (`attribute_id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_user_id_foreign` (`user_id`),
  ADD KEY `carts_item_id_foreign` (`item_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories_items`
--
ALTER TABLE `categories_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_items_category_id_foreign` (`category_id`),
  ADD KEY `categories_items_item_id_foreign` (`item_id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customers_user_id_foreign` (`user_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `employees_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `giftcards`
--
ALTER TABLE `giftcards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `giftcards_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `images_item_id_foreign` (`item_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items_supplier_id_foreign` (`supplier_id`);

--
-- Indexes for table `item_kits`
--
ALTER TABLE `item_kits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item_kit_products`
--
ALTER TABLE `item_kit_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_kit_products_item_kits_id_foreign` (`item_kits_id`),
  ADD KEY `item_kit_products_item_id_foreign` (`item_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `receivings`
--
ALTER TABLE `receivings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `receivings_supplier_id_foreign` (`supplier_id`),
  ADD KEY `receivings_employee_id_foreign` (`employee_id`);

--
-- Indexes for table `receivings_items`
--
ALTER TABLE `receivings_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `receivings_items_receivings_id_foreign` (`receivings_id`),
  ADD KEY `receivings_items_items_id_foreign` (`items_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_customer_id_foreign` (`customer_id`),
  ADD KEY `sales_employee_id_foreign` (`employee_id`),
  ADD KEY `sales_user_id_foreign` (`user_id`);

--
-- Indexes for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_items_sales_id_foreign` (`sales_id`),
  ADD KEY `sales_items_items_id_foreign` (`items_id`);

--
-- Indexes for table `shipping_details`
--
ALTER TABLE `shipping_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shipping_details_sales_id_foreign` (`sales_id`);

--
-- Indexes for table `storeconfigs`
--
ALTER TABLE `storeconfigs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `who_useds`
--
ALTER TABLE `who_useds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `who_useds_user_id_foreign` (`user_id`),
  ADD KEY `who_useds_coupon_id_foreign` (`coupon_id`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wishlists_user_id_foreign` (`user_id`),
  ADD KEY `wishlists_item_id_foreign` (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attributes`
--
ALTER TABLE `attributes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `attribute_values`
--
ALTER TABLE `attribute_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `categories_items`
--
ALTER TABLE `categories_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `giftcards`
--
ALTER TABLE `giftcards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `item_kits`
--
ALTER TABLE `item_kits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `item_kit_products`
--
ALTER TABLE `item_kit_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `receivings`
--
ALTER TABLE `receivings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `receivings_items`
--
ALTER TABLE `receivings_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `sales_items`
--
ALTER TABLE `sales_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `shipping_details`
--
ALTER TABLE `shipping_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `storeconfigs`
--
ALTER TABLE `storeconfigs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `who_useds`
--
ALTER TABLE `who_useds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attribute_values`
--
ALTER TABLE `attribute_values`
  ADD CONSTRAINT `attribute_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`);

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `categories_items`
--
ALTER TABLE `categories_items`
  ADD CONSTRAINT `categories_items_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `categories_items_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`);

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `employees_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `giftcards`
--
ALTER TABLE `giftcards`
  ADD CONSTRAINT `giftcards_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`);

--
-- Constraints for table `item_kit_products`
--
ALTER TABLE `item_kit_products`
  ADD CONSTRAINT `item_kit_products_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `item_kit_products_item_kits_id_foreign` FOREIGN KEY (`item_kits_id`) REFERENCES `item_kits` (`id`);

--
-- Constraints for table `receivings`
--
ALTER TABLE `receivings`
  ADD CONSTRAINT `receivings_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `receivings_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`);

--
-- Constraints for table `receivings_items`
--
ALTER TABLE `receivings_items`
  ADD CONSTRAINT `receivings_items_items_id_foreign` FOREIGN KEY (`items_id`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `receivings_items_receivings_id_foreign` FOREIGN KEY (`receivings_id`) REFERENCES `receivings` (`id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `sales_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD CONSTRAINT `sales_items_items_id_foreign` FOREIGN KEY (`items_id`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `sales_items_sales_id_foreign` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`id`);

--
-- Constraints for table `shipping_details`
--
ALTER TABLE `shipping_details`
  ADD CONSTRAINT `shipping_details_sales_id_foreign` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`id`);

--
-- Constraints for table `who_useds`
--
ALTER TABLE `who_useds`
  ADD CONSTRAINT `who_useds_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `who_useds_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
