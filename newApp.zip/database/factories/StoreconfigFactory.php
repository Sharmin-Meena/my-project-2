<?php

namespace Database\Factories;

use App\Models\Storeconfig;
use Illuminate\Database\Eloquent\Factories\Factory;

class StoreconfigFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Storeconfig::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
